import pandas as pd
import numpy as np
import pickle
career = pd.read_csv('new_dataset0.data', header = None)
#np.dtype('float64')

X = np.array(career.iloc[:, 0:17]) #X is skills
print(X)
y = np.array(career.iloc[:, 17]) #Y is Roles
print("hi: ",len(X))
print('y: ',len(y)) 

##  attribute to return the column labels of the given Dataframe
career.columns = ["Technical Skills","Database management","Programming Skills(C++,Java)",
"Programming Skills(PYTHON)","Mathematics & Statistics Skills","Business and Management Skills","Web Designing "
,"Cloud Services","Cryptography","Leadership Skills","Networking","Communication Skills","Network Security"
,"Hardware Knowledge","Problem Solving","Product Designing","DSA Skills","Role"]

career.dropna(how ='all', inplace = True)
#print("career.dropna(how ='all', inplace = True)",career.dropna(how ='all', inplace = True))
career.head()
## splitting the data into training and test sets 

from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split, GridSearchCV

# Load the data and split it into training and test sets
#42

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=524)

# Define the parameter grid to search over
param_grid = {'hidden_layer_sizes': [(10,), (50,), (100,), (10, 10), (50, 50), (100, 100)], 'alpha': [0.0001, 0.001, 0.01, 0.1]}

# Create an instance of the MLPClassifier model
mlp = MLPClassifier(random_state=42)

# Create an instance of GridSearchCV
grid_search = GridSearchCV(mlp, param_grid, cv=5)

# Fit the GridSearchCV instance to the training data
grid_search.fit(X_train, y_train)

# Make predictions on the test set using the best model
y_pred = grid_search.best_estimator_.predict(X_test)

# Calculate the accuracy of the best model
accuracy = accuracy_score(y_test, y_pred)
print('Accuracy:', accuracy)

# Print the best hyperparameters found by GridSearchCV
print('Best hyperparameters:', grid_search.best_params_)
# pickle.dump(mlp, open('advance_career.pkl','wb'))
print('test file created')


