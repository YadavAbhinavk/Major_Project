<?php
// Initialize the session
session_start();
if(!isset($_SESSION['username']))
{
    header('location:login.php');
}
$con = mysqli_connect('localhost','root');
mysqli_select_db($con,'my_db');
if($con)
{
    $a = "Connected";
}
else 
{
    $a =  "Not connected";
}

?>
<?php include 'header.php'?>



<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		 <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

		 <title>CareerCV-Help you to guide for future</title>


		 <link rel="icon" type="image/x-icon" href="static/icon2.png">

		<!-- Google font -->
		<link href="https://fonts.googleapis.com/css?family=Lato:700%7CMontserrat:400,600" rel="stylesheet">
		

  <link href="{{ url_for('static', filename='chart.css') }}" rel="stylesheet" media="all">
  
  <link href="{{ url_for('static', filename='css1/bootstrap.min.css') }}" rel="stylesheet" media="all">
  
  <link href="{{ url_for('static', filename='css1/font-awesome.min.css') }}" rel="stylesheet" media="all">
  
  <link href="{{ url_for('static', filename='css1/s.css') }}" rel="stylesheet" media="all">
  <link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400' rel='stylesheet' type='text/css'>

  <!-- CSS only -->
<style>
    .card 
    {
        margin:auto;
    }
    .ques_container
    {
        background-color:white;
        background-radius:10px;
        box-shadow: 0 0 10px 2px rgba(100,100,100,0.1);
        width:600px;
        overflow:hidden;
        margin:20px auto;
        
    }
    .ques_header 
    {
        padding: 4rem;
    }
    .ques_container h2 
    {
        padding:1rem;
        text-align:center;
        margin:0;
    }
    ul 
    {
        list-style-type: none;
        padding:0;
    }
    ul li 
    {
        font-size:1.2rem;
        margin:1rem 0 ;
    }
    ul li label 
    {
        cursor: pointer;
    }
    button 
    {
        background-color:purple;
        color:#fff;
        width:600px;
        cursor: pointer;
        border:none;
        display:block;
        font-family:inherit;
        padding:1.3rem;
        font-size:3.5rem;
        text-transform:uppercase;
        margin:10 auto;
        letter-spacing:0.1;
    }
    button:hover 
    {
        background-color:#a60dde;
        letter-spacing:0.5;
        
    }
    button:focus 
    {
        outline:none;
        background-color:#d205f2;

    }
</style>
</head>
<body>
<!--Header-->
        <header id="header" class="transparent-nav" style="position: fixed;background-color: rgb(120, 70, 167); top: 0;">
			<div class="container">

				<div class="navbar-header">
					<!-- Logo -->
					<div class="navbar-brand">
						<a class="logo" href="http://127.0.0.1/php%20CAREERCV/main.php">
							<img src="static/icon2.png" width="30" height="30" class="d-inline-block align-top" alt="">
						CareerCV</a>
					</div>
					<!-- /Logo -->

					<!-- Mobile toggle -->
					<button class="navbar-toggle">
						<span></span>
					</button>
					<!-- /Mobile toggle -->
				</div>

				<?php
					// Check if the user is logged in, if not then redirect him to login page
					if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true):
				?>

				<!-- Navigation -->
				
				<?php else: ?>
					<!-- Navigation -->
				<nav id="nav">
					<ul class="main-menu nav navbar-nav navbar-right">
						<li><a href="http://127.0.0.1/CAREERCV/main.php">Home</a></li>
                        <li class="dropdown">
                            <a class="dropbtn" href="javascript:void(0)">Services <span>&#11167;</span></i></a>
                            <div class="dropdown-content">
								<a href="http://127.0.0.1/CAREERCV/main.php">Career Prediction</a>
                                <a href="http://127.0.0.1/CAREERCV/courses.php">Courses</a>
                                
								<a href="http://127.0.0.1/CAREERCV/blog.php">Knowledge Network</a>
								
                            </div>
                        </li>
						<li><a href="#about">About Us</a></li>
						<li><a href="http://127.0.0.1/CAREERCV/contact.php">Contact Us</a></li>
						<li><a href="http://127.0.0.1/CAREERCV/logout.php" >Log out</a></li>
						
                        
					</ul>
				</nav>
				<!-- /Navigation -->
				<?php endif ?>

			</div>
		</header>
		<div class="hero-area section">

			<!-- Backgound Image -->
			<div class="bg-image bg-parallax overlay" style="background-image:url(static/img/bgc2.jpg); " ></div>
			<!-- /Backgound Image -->

			<div class="container">
				<div class="row" >
					<div class="col-md-10 col-md-offset-1 text-center">
						
						<h1 class="white-text">Lets' Start the Quiz</h1>

					</div>
				</div>
			</div>

		</div>

    <!-- Icons font CSS-->

    <link href=" {{ url_for('static', filename='vendor/mdi-font/css/material-design-iconic-font.min.css') }}" rel="stylesheet" media="all">

    <link href="{{ url_for('static', filename='vendor/font-awesome-4.7/css/font-awesome.min.css') }}" rel="stylesheet" media="all">
    <link href="{{ url_for('static', filename='css/range.scss') }}" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">

    <!-- Vendor CSS-->

    <link href="{{ url_for('static', filename='vendor/select2/select2.min.css') }}" rel="stylesheet" media="all">

    <link href="{{ url_for('static', filename='vendor/datepicker/daterangepicker.css') }}" rel="stylesheet" media="all">
      <!-- Main CSS-->

    <link href="{{ url_for('static', filename='css/main.css') }}" rel="stylesheet" media="all">
</head>

<body>
<div class="page-wrapper bg-gra-03 p-t-45 p-b-50">
        <div class="wrapper wrapper--w790">
            <div class="ques_container ">
                <div class="ques_header">
                    <h2 class="title" style="color:#7846a7;text-align:justify;font-size:25px;">This Skill Test Quiz is to judge your skills level for the predicted job profile and let you know what are the topics you need to focus more.</h2>
				
                </div>
                <br>
                <form action="for_beginner.php" method="post" >
                <input type="text" name="job1" value="<?php echo $_POST['job1']; ?>" id="" style="border:none;color:white;font-size:0;display:none;">
                            
                <?php
                
                    $q = "select * from questions where career_name='".$_POST['job1']."';";
                
                $query = mysqli_query($con,$q);
                $i = 0;
                while($rows = mysqli_fetch_array($query)) {
                    $i++;
                    ?>
                    <div class="ques_container">
                        <div class="ques_header">
                            <h2 style="text-align:justify;font-size:20px;"><?php  echo $i.". ".$rows['question_name']; ?></h2>
                            
                            <ul>
                                <li>
                                    <input type="radio" name="quizcheck[<?php echo $rows['answer']; ?>]" id="a" class="answer" value="<?php echo $rows['option1']; ?>">
                                    <label ><?php echo $rows['option1']; ?></label>
                                </li>
                                <li>
                                    <input type="radio" name="quizcheck[<?php echo $rows['answer']; ?>]" id="b" class="answer" value="<?php echo $rows['option2']; ?>">
                                    <label ><?php echo $rows['option2']; ?></label>
                                </li>
                                <li>
                                    <input type="radio" name="quizcheck[<?php echo $rows['answer']; ?>]" id="c" class="answer" value="<?php echo $rows['option3']; ?>">
                                    <label ><?php echo $rows['option3']; ?></label>
                                </li>
                                <li>
                                    <input type="radio" name="quizcheck[<?php echo $rows['answer']; ?>]" id="d" class="answer" value="<?php echo $rows['option4']; ?>">
                                    <label ><?php echo $rows['option4']; ?></label>
                                </li>
                            </ul>
                            
                        </div>
                    </div>
                    
                    <?php 
                }
                ?>
                <input type="text" value="<?php echo $i;?>" name="i" style="display:none;">
<button id="submit" type="submit" value="Submit" name="submit">Submit</button>
            </form>





        <!-- Footer -->
		<footer id="footer" class="section">

<!-- container -->
<div class="container">

    <!-- row -->
    <div class="row">

        <!-- footer logo -->
        <div class="col-md-6">
            <div class="footer-logo">
                <a class="logo" style="font-size: 30px;" href="main.php">CareerCV</a>
            </div>
        </div>
        <!-- footer logo -->


    </div>
    <!-- /row -->

    <!-- row -->
    <div id="bottom-footer" class="row">

        <!-- social -->
        <div class="col-md-4 col-md-push-8">
        </div>
        <!-- /social -->

        <!-- copyright -->
        <div class="col-md-8 col-md-pull-4">
            <div class="footer-copyright">
                <span>&copy; Copyright 2022. All Rights Reserved. </span>
            </div>
        </div>
        <!-- /copyright -->

    </div>
    <!-- row -->

</div>
<!-- /container -->

</footer>
<!-- /Footer -->

<!-- preloader -->
<div id='preloader'><div class='preloader'></div></div>
<!-- /preloader -->

<!-- jQuery Plugins -->
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/main.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
</body>
</html>
