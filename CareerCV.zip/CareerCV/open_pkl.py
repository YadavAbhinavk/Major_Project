import pickle
import numpy as num
import seaborn as sns
import pandas as pd
# with open('careerlast.pkl','rb') as file:
#     data = pickle.load(file)
# list_file = list(file)

# print(file)/

df = pd.read_csv('dataset0.csv')
# print(df.head())

filename = 'advance_career.pkl' 

# serialized process
pickle.dump(df,open(filename,'wb'))

# unserialized
dfa = pickle.load(open(filename,'rb'))

print("This is unpickled\n",dfa.head())