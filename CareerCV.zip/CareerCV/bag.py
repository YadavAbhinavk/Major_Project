from sklearn import model_selection
from sklearn.ensemble import BaggingClassifier
from sklearn.tree import DecisionTreeClassifier
import pandas as pd
import numpy as np
import pickle
  
# load the data
dataset = pd.read_csv('dataset0.data', header = None)
print(dataset.head())
X=np.array(dataset.iloc[:, 0:21]) 
print(X)
Y = np.array(dataset.iloc[:, 20])
print(Y)
dataset.columns= ["Technical Skills","Database management","Programming Skills(C++,Java)",
"Programming Skills(PYTHON)","Mathematics & Statistics Skills","Business and Management Skills","Web Designing "
,"Critical Thinking","Cloud Services","Cryptography","Leadership Skills","Telecommunication","Networking","Communication Skills","Network Security"
,"Hardware Knowledge","Problem Solving","Product Designing","DSA Skills","Knowledge of Automation Tools","System Design","Role"]
dataset.dropna(how ='all', inplace = True)

  
seed =5 
kfold = model_selection.KFold(n_splits = 15,
                       random_state = seed)
  
# initialize the base classifier
base_cls = DecisionTreeClassifier()
  
# no. of base classifier
num_trees = 50
  
# bagging classifier
model = BaggingClassifier(base_estimator = base_cls,
                          n_estimators = num_trees,
                          random_state = seed)
  
results = model_selection.cross_val_score(model, X, Y, cv = kfold)
print("accuracy :",results.mean()*100)


