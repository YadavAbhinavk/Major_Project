import re
from pdfminer.high_level import extract_pages,extract_text
UPLOAD_FOLDER = 'C:/xampp/htdocs/CareerCV/Uploaded_Resumes'
save_image_path = UPLOAD_FOLDER+'/'+'Resume.pdf'
print(save_image_path)
text = extract_text(save_image_path)


new_text = re.sub(',','',text)
print(new_text)
list1 = new_text.split()

skills = []
# print(list1)

