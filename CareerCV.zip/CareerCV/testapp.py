from flask import Flask, render_template, request
import requests
import pickle
import numpy as np
import nltk
import streamlit as st
import pandas as pd
import base64,random
import time,datetime
import PyPDF2
import re
from pdfminer.high_level import extract_pages,extract_text
import json
from pdfminer3.layout import LAParams, LTTextBox
from pdfminer3.pdfpage import PDFPage
from pdfminer3.pdfinterp import PDFResourceManager
from pdfminer3.pdfinterp import PDFPageInterpreter
from pdfminer3.converter import TextConverter
import io,random
from streamlit_tags import st_tags
from PIL import Image
from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileRequired
from werkzeug.utils import secure_filename
from pdfreader import SimplePDFViewer, PageDoesNotExist
from PyPDF2 import PdfReader
import plotly.express as px
import os
import docx

app = Flask(__name__)

ds_keyword = ['tensorflow','keras','pytorch','machine learning','deep Learning','flask','streamlit'] 
web_keyword = ['react', 'django', 'node jS', 'react js', 'php', 'laravel', 'magento', 'wordpress','javascript', 'angular js', 'c#', 'flask','html','css']
android_keyword = ['android','android development','flutter','kotlin','xml','kivy']
ios_keyword = ['ios','ios development','swift','cocoa','cocoa touch','xcode']
uiux_keyword = ['ux','adobe xd','figma','zeplin','balsamiq','ui','prototyping','wireframes','storyframes','adobe photoshop','photoshop','editing','adobe illustrator','illustrator','adobe after effects','after effects','adobe premier pro','premier pro','adobe indesign','indesign','wireframe','solid','grasp','user research','user experience']
database_keyword = ["Microsoft SQL Server", "Oracle Database", "PL/SQL", "Linux", "Oracle RAC", "RMAN", "MySQL", "ITIL", "PostgreSQL", "SQL Tuning"]
software_keyword = ['Python', 'Java', 'C++', 'JavaScript', 'Ruby', 'PHP', 'Swift', 'Kotlin', 'Go', 'Rust', 'TypeScript','Agile', 'Scrum', 'Waterfall','algorithms and data structures','problem-solving','algorithm','data structures','DSA']

nltk.download('punkt')
# nlp = spacy.load('en_core_web_sm')


UPLOAD_FOLDER = 'C:/xampp/htdocs/CareerCV/Uploaded_Resumes'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER



@app.route('/')
def career():
    return render_template("hometest.html")

@app.route('/home')
def play():
    return render_template("advance_test.html")

@app.route('/resume_analysis',methods = ['POST', 'GET'])
def resume_analysis(): 

    return render_template("resume.html")  

@app.route('/predict',methods = ['POST', 'GET'])
def result():
   if request.method == 'POST':
      result = request.form
      i = 0
      print(result)
      res = result.to_dict(flat=True)
      print("res:",res)
      arr1 = res.values()
      arr = ([value for value in arr1])

      data = np.array(arr,dtype=float)

      data = data.reshape(1,-1)
      print(data)
      loaded_model = pickle.load(open("careerlast.pkl", 'rb'))
      predictions = loaded_model.predict(data)
     # return render_template('testafter.html',a=predictions)
      
      print("prediction: ",predictions)
      pred = loaded_model.predict_proba(data)
      print("pred:  ",len(pred))
      #acc=accuracy_score(pred,)
      pred = pred > 0.05
      #print(predictions)
      i = 0
      j = 0
      index = 0
      res = {}
      final_res = {}
      while j < 17:
          if pred[i, j]:
              res[index] = j
              index += 1
              print("pred: ",pred[i,j])
          j += 1
          print(j)
      #print(res)
      index = 0
      for key, values in res.items():
          if values != predictions[0]:
              final_res[index] = values
              print('final_res[index]:',final_res[index])
              index += 1
      #print(final_res)
      jobs_dict = {0:'AI ML Specialist',
                   1:'API Integration Specialist',
                   2:'Application Support Engineer',
                   3:'Business Analyst',
                   4:'Customer Service Executive',
                   5:'Cyber Security Specialist',
                   6:'Data Scientist',
                   7:'Database Administrator',
                   8:'Graphics Designer',
                   9:'Hardware Engineer',
                   10:'Helpdesk Engineer',
                   11:'Information Security Specialist',
                   12:'Networking Engineer',
                   13:'Project Manager',
                   14:'Software Developer',
                   15:'Software Tester',
                   16:'Technical Writer'}
                
      #print(jobs_dict[predictions[0]])
      job = {}
      #job[0] = jobs_dict[predictions[0]]
      index = 1
     
        
      data1=predictions[0]
      print("data1:  ",data1)
      return render_template("testafter.html",final_res=final_res,job_dict=jobs_dict,job0=data1)


@app.route('/prediction',methods = ['POST', 'GET'])
def result_form():
   if request.method == 'POST':
      result = request.form
      i = 0
      print(result)
      res = result.to_dict(flat=True)
      print("res:",res)
      arr1 = res.values()
      arr = ([value for value in arr1])

      data = np.array(arr,dtype=float)

      data = data.reshape(1,-1)
      print("data is:\n",data)
      loaded_model = pickle.load(open("knn-model_career.pkl", 'rb'))
      predictions = loaded_model.predict(data)
     # return render_template('testafter.html',a=predictions)
      
      
      pred = loaded_model.predict_proba(data)
      print(pred)
      #acc=accuracy_score(pred,)
      pred = pred > 0.05
      print("predictions: ",predictions)
      i = 0
      j = 0
      index = 0
      res = {}
      final_res = {}
      while j < 17:
          if pred[i, j]:
              res[index] = j
              index += 1
              
          j += 1
          print(j)
      # print(j)
      print("res: ",res)
      index = 0
      for key, values in res.items():
          if values != predictions[0]:
              final_res[index] = values
              print('final_res[index]:',final_res[index])
              index += 1
      print("final_res",final_res)
      jobs_dict = {0:'AI ML Specialist',
                   1:'Business Analyst',
                   2:'Customer Service Executive',
                   3:'Cyber Security Specialist',
                   4:'Data Scientist',
                   5:'Database Administrator',
                   6:'Graphics Designer',
                   7:'Hardware Engineer',
                   8:'Networking Engineer',
                   9:'Project Manager',
                   10:'Software Developer',
                   11:'Software Tester',
                   12:'Technical Writer',
                   13:'Cloud Engineer',
                   14:'Front-End Engineer',
                   15:'Back-End Engineer',
                   16:'Full-Stack Developer',
                   17:'Web Development',
                   18:'Product Manager',
                   19:'Solution Architect'}
                
      #print(jobs_dict[predictions[0]])
      job = {}
      #job[0] = jobs_dict[predictions[0]]
      index = 1
      print(final_res)
      print(jobs_dict)
    #   for i in jobs_dict:
    #       print("i: ",final_res[i])  
      data1=predictions[0]
      print("data1:  ",data1)
      return render_template("test_after.html",final_res=final_res,job_dict=jobs_dict,job0=data1)

def show_pdf(file_path):
    with open(file_path, "rb") as f:
        base64_pdf = base64.b64encode(f.read()).decode('utf-8')       
@app.route('/resume_parser',methods = ['POST', 'GET'])
def resume_parser():
    if request.method == 'POST':
       result = request.files["file"]
       result.save(os.path.join(app.config['UPLOAD_FOLDER'],result.filename))
       i = 0
       print("result:   ",result.filename) 
       save_image_path = UPLOAD_FOLDER+'/'+result.filename
       print(save_image_path)

       text = extract_text(save_image_path)

       new_text = re.sub(',','',text)

       resume_text_list = new_text.split()

    #    print(resume_text_list)
       job_field = []
       for i in resume_text_list:
           if i in ds_keyword and 'Data Science' not in job_field:
               job_field.append('Data Science')
           if i in web_keyword and 'Web Development' not in job_field: 
               job_field.append('Web Development')   
           if i in android_keyword and 'Android Developer' not in job_field: 
               job_field.append('Android Developer')   
           if i in ios_keyword and 'Ios Development' not in job_field: 
               job_field.append('Ios Development')   
           if i in uiux_keyword and 'UI-UX Designer' not in job_field: 
               job_field.append('UI-UX Designer')   
           if i in database_keyword and 'Datbase Administrator' not in job_field: 
               job_field.append('Datbase Administrator')       
           if i in software_keyword and 'Software Developer' not in job_field: 
               job_field.append('Software Developer')          
       print(job_field)
    return render_template("resume.html",job_field=job_field)  
   

if __name__ == '__main__':
   app.run(debug = True)
