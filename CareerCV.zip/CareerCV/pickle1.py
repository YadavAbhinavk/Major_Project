import os,pickle,pandas
# import cPickle
# data=pickle.load("careerlast.pkl")
scores = {}
target = "careerlast.pkl"
# # if(os.path.getsize(target)>0):
#     with open(target,'rb') as f:
#         unpickler = pickle.Unpickler(f)
#         scores = unpickler.load()
df = pandas.read_pickle(target)
# df = pandas.DataFrame(data)
# df.to_csv(r'file.csv')
# df.n_features_in_ = 21
print(df)