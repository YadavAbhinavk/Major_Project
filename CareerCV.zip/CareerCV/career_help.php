<?php
// Initialize the session
session_start();
if(!isset($_SESSION['username']))
{
    header('location:login.php');
}
$con = mysqli_connect('localhost','root');
mysqli_select_db($con,'my_db');
if($con)
{
    $a = "Connected";
}
else 
{
    $a =  "Not connected";
}

?>
<?php include 'header.php'?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		 <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

		 <title>CareerCV-Help you to guide for future</title>


		 <link rel="icon" type="image/x-icon" href="static/icon2.png">

		<!-- Google font -->
		<link href="https://fonts.googleapis.com/css?family=Lato:700%7CMontserrat:400,600" rel="stylesheet">
		

  <link href="{{ url_for('static', filename='chart.css') }}" rel="stylesheet" media="all">
  
  <link href="{{ url_for('static', filename='css1/bootstrap.min.css') }}" rel="stylesheet" media="all">
  
  <link href="{{ url_for('static', filename='css1/font-awesome.min.css') }}" rel="stylesheet" media="all">
  
  <link href="{{ url_for('static', filename='css1/s.css') }}" rel="stylesheet" media="all">
  <link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400' rel='stylesheet' type='text/css'>

  <!-- CSS only -->
<style>
    .card 
    {
        margin:auto;
    }
    .ques_container
    {
        background-color:white;
        background-radius:10px;
        box-shadow: 0 0 10px 2px rgba(100,100,100,0.1);
        width:600px;
        overflow:hidden;
        margin:20px auto;
        
    }
    .ques_header 
    {
        padding: 4rem;
    }
    .ques_container h2 
    {
        padding:1rem;
        text-align:center;
        margin:0;
    }
    ul 
    {
        list-style-type: none;
        padding:0;
    }
    ul li 
    {
        font-size:1.2rem;
        margin:1rem 0 ;
    }
    ul li label 
    {
        cursor: pointer;
    }
    button 
    {
        background-color:purple;
        color:#fff;
        width:600px;
        cursor: pointer;
        border:none;
        display:block;
        font-family:inherit;
        padding:1.3rem;
        font-size:3.5rem;
        text-transform:uppercase;
        margin: 1 auto;
        letter-spacing:0.1;

    }
    button:hover 
    {
        background-color:#a60dde;
        letter-spacing:0.5;
        
    }
    button:focus 
    {
        outline:none;
        background-color:#d205f2;

    }
</style>
</head>
<body>
<header id="header" class="transparent-nav" style="position: fixed;background-color: rgb(120, 70, 167); top: 0;">
</header>
<div class="hero-area section">

<!-- Backgound Image -->
<div class="bg-image bg-parallax overlay" style="background-image:url(static/img/bgc2.jpg); " ></div>
<!-- /Backgound Image -->

<div class="container">
    <div class="row" >
        <div class="col-md-10 col-md-offset-1 text-center">
            
            <h1 class="white-text">Career Guidance will guide students of different age groups and professionals to choose better career options for them.</h1>

        </div>
    </div>
</div>

</div>
				<form action="">
                    <br><br><br>
                <div class="ques_container">
                        <div class="ques_header">
                            <div>
                            <label for="">Enter Name:</label>
                            <input type="text" name="" id="">
                            </div>
                            

                            <br>
                            <div>
                            <label for="">Enter Email:</label>
                            <input type="text" name="" id="">
                            </div>
                            

                            <br>
                            <div>
                            <label>Enter Qualification:</label><br>
                            <div>
							 <select class="form-select form-control" id="myselect" required aria-label="select example" name="rate_qualification" onchange="redirect_to(this.value)">
							        <option disabled= "disabled" selected="selected">Choose option</option>
									<option id="opt1" value="for_beginner.php">Doing Graduation</option>
									<option value="for_beginner.php">Graduation Complete</option>
									<option value="#">Work Experienced</option>
									
							 </select>
						    </div>
                            </div>
                            <br><br>
                            <!-- <button id="submit  name="submit" onclick="run()">Submit</button> -->

</div>
                    </div>

                    <script>
                        function redirect_to(src)
                        {
                            window.location = src;
                        };

                    </script>
                    </body>
                    </html>
