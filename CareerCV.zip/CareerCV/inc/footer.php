<div class="col-md-12 footer">
    <div class="col-sm-6 pull-right">
        <p class="text-right">All Rights reserved by <a href="#">Resume Parser</a></p>
    </div>
</div>